# Foundations, Bonds, and CAPM

This zip is a ready-to-use Overleaf project for a mock TIØ4145 exam.

## Files

- `mock_01.tex` — questions only. Compile this to get the printable
  question paper with blank answer space after each short question.
- `mock_01_solutions.tex` — questions plus the correct option highlighted
  (for MCQ) and the model answer / rubric (for written questions).

## Opening in Overleaf

1. Go to https://www.overleaf.com.
2. New Project → Upload Project → drop this zip in.
3. Pick the `.tex` you want to compile and click Recompile.

The preamble uses standard packages (`amsmath`, `enumitem`, `tcolorbox`,
`hyperref`) so any reasonably recent TeX Live distribution will compile
it locally too: `latexmk -pdf mock_01.tex`.
